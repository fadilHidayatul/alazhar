-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2021 at 06:18 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_alazhar1`
--

-- --------------------------------------------------------

--
-- Table structure for table `cle`
--

CREATE TABLE `cle` (
  `id_kirim_tugas` bigint(20) UNSIGNED NOT NULL,
  `id_tugas` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tgl_kirim_tugas` date NOT NULL,
  `file_tugas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ket_tugas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2021_02_05_105433_create_admin__models_table', 1),
(4, '2021_02_10_071142_create_user__models_table', 2),
(5, '2021_02_10_073457_create_absensi__models_table', 2),
(6, '2021_02_10_074358_create_cuti__models_table', 2),
(7, '2021_02_10_074910_create_guru__models_table', 2),
(8, '2021_02_10_075114_create_jabatan__models_table', 2),
(10, '2021_02_10_081438_create_jadwal_ujian__models_table', 2),
(11, '2021_02_10_081805_create_jam_ajar__models_table', 2),
(13, '2021_02_10_082340_create_lapor__models_table', 2),
(14, '2021_02_10_082641_create_pegawai__models_table', 2),
(15, '2021_02_10_083323_create_pelajaran__models_table', 2),
(16, '2021_02_10_083504_create_siswa__models_table', 2),
(20, '2021_02_13_081145_create_hari__models_table', 5),
(21, '2021_02_10_080904_create_jadwal_pelajaran__models_table', 6),
(23, '2021_02_10_084039_create_s_p_p__models_table', 7),
(27, '2021_02_15_111121_create_smester__models_table', 7),
(31, '2021_02_10_082133_create_kelas__models_table', 8),
(32, '2021_02_15_110257_create_quis__models_table', 9),
(33, '2021_02_15_110717_create_nilai__models_table', 9),
(34, '2021_02_15_110902_create_tugas__models_table', 9),
(35, '2021_02_15_111411_create_materi__models_table', 9),
(37, '2021_02_15_112605_create_izin__models_table', 10),
(38, '2021_02_15_111715_create_kirim_tugas__models_table', 11);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_absensi`
--

CREATE TABLE `tb_absensi` (
  `id_absen` bigint(20) UNSIGNED NOT NULL,
  `id_pegawai` int(11) NOT NULL,
  `jam_ke` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `jam_masuk` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_absensi`
--

INSERT INTO `tb_absensi` (`id_absen`, `id_pegawai`, `jam_ke`, `tanggal`, `jam_masuk`, `jam_selesai`, `alamat`, `keterangan`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 2, '2004-07-22', '02:55:00', '16:39:00', '4', 'Consequatur natus c', '2021-02-15 02:55:24', '2021-02-15 02:55:24', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `admin_id` bigint(20) UNSIGNED NOT NULL,
  `admin_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_notelp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`, `admin_notelp`, `admin_level`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$0x72Pt/C6luSevA9dAsw0uyk9YN6XzrUFS/nzW4.1ncWOooxUingu', '0238423742', 'admin', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_cuti`
--

CREATE TABLE `tb_cuti` (
  `id_cuti` bigint(20) UNSIGNED NOT NULL,
  `nip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lama_cuti` int(11) NOT NULL,
  `alasan_cuti` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_akhir` date NOT NULL,
  `tanggal` date NOT NULL,
  `tanggal_acc` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_guru`
--

CREATE TABLE `tb_guru` (
  `id_guru` bigint(20) UNSIGNED NOT NULL,
  `nama_guru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nip_guru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_hari`
--

CREATE TABLE `tb_hari` (
  `id_hari` bigint(20) UNSIGNED NOT NULL,
  `hari` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_hari`
--

INSERT INTO `tb_hari` (`id_hari`, `hari`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Senin', '2021-02-13 01:24:40', '2021-02-13 01:25:22', NULL),
(2, 'Selasa', '2021-02-13 01:25:32', '2021-02-13 01:25:32', NULL),
(3, 'Rabu', '2021-02-13 01:25:40', '2021-02-13 01:25:40', NULL),
(4, 'Kamis', '2021-02-13 01:25:50', '2021-02-13 01:25:50', NULL),
(5, 'Jumat', '2021-02-13 01:25:59', '2021-02-13 01:25:59', NULL),
(6, 'Sabtu', '2021-02-13 01:26:11', '2021-02-13 01:26:11', NULL),
(7, 'Minggu', '2021-02-13 01:26:19', '2021-02-13 01:26:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_izin`
--

CREATE TABLE `tb_izin` (
  `id_izin` bigint(20) UNSIGNED NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `keterangan_izin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl_izin` date NOT NULL,
  `foto_izin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_izin`
--

INSERT INTO `tb_izin` (`id_izin`, `id_siswa`, `keterangan_izin`, `tgl_izin`, `foto_izin`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 5, 'Ut esse et quae face', '2000-10-12', '1613962853.jpg', '2021-02-21 20:00:53', '2021-02-21 20:00:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_jabatan`
--

CREATE TABLE `tb_jabatan` (
  `id_jabatan` bigint(20) UNSIGNED NOT NULL,
  `nama_jabatan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_jabatan`
--

INSERT INTO `tb_jabatan` (`id_jabatan`, `nama_jabatan`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Kepala Sekolah', '2021-02-10 08:47:00', '2021-02-10 08:47:00', NULL),
(2, 'Wali Kelas', '2021-02-10 08:47:13', '2021-02-10 08:47:13', NULL),
(3, 'Guru', '2021-02-10 08:47:26', '2021-02-10 08:47:26', NULL),
(4, 'Tata Usaha', '2021-02-10 08:47:44', '2021-02-10 08:47:44', NULL),
(5, 'Operator', '2021-02-10 08:47:56', '2021-02-10 08:47:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_jadwal_pelajaran`
--

CREATE TABLE `tb_jadwal_pelajaran` (
  `id_jadwal_pelajaran` bigint(20) UNSIGNED NOT NULL,
  `id_jam_ajar` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_pelajaran` int(11) NOT NULL,
  `id_pegawai` int(11) NOT NULL,
  `id_hari` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_jadwal_pelajaran`
--

INSERT INTO `tb_jadwal_pelajaran` (`id_jadwal_pelajaran`, `id_jam_ajar`, `id_kelas`, `id_pelajaran`, `id_pegawai`, `id_hari`, `created_at`, `updated_at`, `deleted_at`) VALUES
(5, 3, 1, 3, 4, '1', '2021-02-14 20:35:54', '2021-02-14 20:35:54', NULL),
(6, 2, 2, 2, 4, '7', '2021-02-14 20:36:38', '2021-02-14 22:02:59', NULL),
(7, 3, 4, 3, 4, '3', '2021-02-14 22:03:33', '2021-02-14 22:04:58', NULL),
(8, 3, 1, 2, 5, '1', '2021-02-14 20:35:54', '2021-02-14 20:35:54', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_jadwal_ujian`
--

CREATE TABLE `tb_jadwal_ujian` (
  `id_jadwal_ujian` bigint(20) UNSIGNED NOT NULL,
  `id_jam_ajar` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_pelajaran` int(11) NOT NULL,
  `id_guru` int(11) NOT NULL,
  `hari_jadwal` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_jam_ajar`
--

CREATE TABLE `tb_jam_ajar` (
  `id_jam` bigint(20) UNSIGNED NOT NULL,
  `jam_awal` time NOT NULL,
  `jam_akhir` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_jam_ajar`
--

INSERT INTO `tb_jam_ajar` (`id_jam`, `jam_awal`, `jam_akhir`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, '12:03:00', '12:13:00', '2021-02-11 03:06:28', '2021-02-11 03:06:45', NULL),
(3, '11:26:00', '00:26:00', '2021-02-12 20:26:59', '2021-02-12 20:26:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_kelas`
--

CREATE TABLE `tb_kelas` (
  `id_kelas` bigint(20) UNSIGNED NOT NULL,
  `id_semester` int(11) DEFAULT NULL,
  `nama_kelas` int(11) NOT NULL,
  `grup_kelas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_kelas`
--

INSERT INTO `tb_kelas` (`id_kelas`, `id_semester`, `nama_kelas`, `grup_kelas`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 3, 'B', '2021-02-16 02:18:33', '2021-02-16 02:18:33', NULL),
(2, 1, 1, 'A', '2021-02-16 02:18:44', '2021-02-16 02:18:44', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_kirim_tugas`
--

CREATE TABLE `tb_kirim_tugas` (
  `id_kirim_tugas` bigint(20) UNSIGNED NOT NULL,
  `id_tugas` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tgl_kirim_tugas` date NOT NULL,
  `file_tugas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ket_tugas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_kirim_tugas`
--

INSERT INTO `tb_kirim_tugas` (`id_kirim_tugas`, `id_tugas`, `id_user`, `tgl_kirim_tugas`, `file_tugas`, `ket_tugas`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 3, 6, '1989-03-06', '1613707753.pdf', 'Iusto proident volu', '2021-02-18 21:06:14', '2021-02-18 21:09:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_lapor`
--

CREATE TABLE `tb_lapor` (
  `id_lapor` bigint(20) UNSIGNED NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_lapor`
--

INSERT INTO `tb_lapor` (`id_lapor`, `id_siswa`, `id_kelas`, `file`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, 5, 2, '1613378331.pdf', '2021-02-15 01:38:51', '2021-02-15 01:38:51', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_materi`
--

CREATE TABLE `tb_materi` (
  `id_materi` bigint(20) UNSIGNED NOT NULL,
  `id_pelajaran` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `materi_pelajaran` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_pelajaran` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_materi`
--

INSERT INTO `tb_materi` (`id_materi`, `id_pelajaran`, `id_kelas`, `materi_pelajaran`, `nama_pelajaran`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 2, 1, '1613700347.pdf', 'In iste alias dolore', '2021-02-18 19:05:34', '2021-02-18 19:05:47', NULL),
(4, 3, 2, '1613700377.pdf', 'Mollitia duis dolore', '2021-02-18 19:06:17', '2021-02-18 19:06:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_nilai`
--

CREATE TABLE `tb_nilai` (
  `id_nilai` bigint(20) UNSIGNED NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `id_pelajaran` int(11) NOT NULL,
  `nilai` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_nilai`
--

INSERT INTO `tb_nilai` (`id_nilai`, `id_siswa`, `id_pelajaran`, `nilai`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 5, 3, 93, '2021-02-18 23:25:35', '2021-02-18 23:25:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pegawai`
--

CREATE TABLE `tb_pegawai` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_peg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jabatan_id` int(11) NOT NULL,
  `Email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_tlp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl_masuk` date NOT NULL,
  `tmp_lahir` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pendidikan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_pegawai`
--

INSERT INTO `tb_pegawai` (`id`, `nip`, `nama_peg`, `jabatan_id`, `Email`, `no_tlp`, `alamat`, `tgl_masuk`, `tmp_lahir`, `agama`, `gender`, `pendidikan`, `foto`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 'Corporis in voluptat', 'Unde quisquam est la', 4, 'fisar@mailinator.com', '5515151515', 'Hic sunt enim volupt', '2003-01-21', 'Aut modi est esse de', 'Consequatur rerum au', 'Pria', 'Possimus qui ut ips', '1613010957.png', '2021-02-10 19:35:57', '2021-02-10 19:35:57', NULL),
(4, '5346465456465', 'Amet nihil eu eiusm', 3, 'wyjapacidu@mailinator.com', '5465454', 'Autem dolor culpa mi', '1999-05-23', 'Autem alias proident', 'In vero officiis nob', 'Wanita', 'Placeat voluptatem', '1613209639.JPG', '2021-02-13 02:47:19', '2021-02-13 02:47:19', NULL),
(5, '1213312', 'Id delectus placeat', 3, 'kepuxamof@mailinator.com', '123123123', 'Error veniam quis n', '1976-10-06', 'Culpa laboris volupt', 'Veniam et cum conse', 'Pria', 'Reprehenderit quis r', '1613467374.JPG', '2021-02-16 02:22:54', '2021-02-16 02:22:54', NULL),
(6, '10101010010101', 'Admin', 4, 'kepuxa@mailinator.com', '123123123', 'Error veniam quis n', '1976-10-06', 'Culpa laboris volupt', 'Veniam et cum conse', 'Pria', 'Reprehenderit quis r', '1613209639.jpg', '2021-02-16 02:22:54', '2021-02-16 02:22:54', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pelajaran`
--

CREATE TABLE `tb_pelajaran` (
  `id_pelajaran` bigint(20) UNSIGNED NOT NULL,
  `nama_pelajaran` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_pelajaran`
--

INSERT INTO `tb_pelajaran` (`id_pelajaran`, `nama_pelajaran`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'kimia', '2021-02-13 02:48:56', '2021-02-13 02:48:56', NULL),
(3, 'fisika', '2021-02-13 02:49:04', '2021-02-13 02:49:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_quis`
--

CREATE TABLE `tb_quis` (
  `id_quis` bigint(20) UNSIGNED NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_pelajaran` int(11) NOT NULL,
  `soal` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pil_a` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pil_b` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pil_c` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pil_d` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `kunci` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_quis`
--

INSERT INTO `tb_quis` (`id_quis`, `id_kelas`, `id_pelajaran`, `soal`, `pil_a`, `pil_b`, `pil_c`, `pil_d`, `kunci`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 2, 2, 'Nemo atque sequi qui', 'Corrupti excepteur', 'Illum animi itaque', 'Magni doloremque qui', 'Magnam deleniti sunt', 'Ut rerum repellendus', '2021-02-18 21:46:13', '2021-02-18 21:46:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_semester`
--

CREATE TABLE `tb_semester` (
  `id_semester` bigint(20) UNSIGNED NOT NULL,
  `semester` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_semester`
--

INSERT INTO `tb_semester` (`id_semester`, `semester`, `created_at`, `updated_at`) VALUES
(1, 'Ganjil', '2021-02-16 01:33:50', '2021-02-16 01:34:16'),
(2, 'Genap', '2021-02-16 01:33:59', '2021-02-16 01:33:59');

-- --------------------------------------------------------

--
-- Table structure for table `tb_siswa`
--

CREATE TABLE `tb_siswa` (
  `id_siswa` bigint(20) UNSIGNED NOT NULL,
  `nama_siswa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender_siswa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nohp_siswa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempat_lahir_siswa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_lahir_siswa` date NOT NULL,
  `alamat_siswa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_siswa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_daftar` int(11) NOT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_siswa`
--

INSERT INTO `tb_siswa` (`id_siswa`, `nama_siswa`, `gender_siswa`, `nohp_siswa`, `tempat_lahir_siswa`, `tanggal_lahir_siswa`, `alamat_siswa`, `foto_siswa`, `status_daftar`, `id_kelas`, `created_at`, `updated_at`, `deleted_at`) VALUES
(5, 'Sapiente sed cumque', 'Pria', '84', 'Incididunt cupiditat', '2011-03-01', 'Dolorum in quo facil', '1613385716.JPG', 0, 2, '2021-02-14 22:15:01', '2021-02-15 03:41:56', NULL),
(6, 'Qui nihil perferendi', 'Pria', '27', 'Dolor dolorem nostru', '2013-07-12', 'Omnis dolores volupt', '1613467394.JPG', 0, 1, '2021-02-16 02:23:14', '2021-02-16 02:23:14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_spp`
--

CREATE TABLE `tb_spp` (
  `id_spp` bigint(20) UNSIGNED NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `bulan_spp` int(11) NOT NULL,
  `tahun_spp` int(11) NOT NULL,
  `tgl_bayar` date NOT NULL,
  `upload_bukti` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_spp`
--

INSERT INTO `tb_spp` (`id_spp`, `id_siswa`, `bulan_spp`, `tahun_spp`, `tgl_bayar`, `upload_bukti`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 5, 3, 2020, '2003-01-21', 'asdas.jpg', 1, NULL, NULL, NULL),
(2, 5, 3, 2021, '2003-01-21', 'asdas.jpg', 0, NULL, NULL, NULL),
(3, 5, 4, 2021, '2003-01-21', 'asdas.jpg', 0, NULL, NULL, NULL),
(4, 5, 5, 2021, '2003-01-21', 'asdas.jpg', 0, NULL, NULL, NULL),
(5, 5, 2, 2021, '2003-01-21', 'asdas.jpg', 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_tugas`
--

CREATE TABLE `tb_tugas` (
  `id_tugas` bigint(20) UNSIGNED NOT NULL,
  `id_pelajaran` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `judul_tugas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isi_tugas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_tugas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deadline_tugas` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_tugas`
--

INSERT INTO `tb_tugas` (`id_tugas`, `id_pelajaran`, `id_kelas`, `judul_tugas`, `isi_tugas`, `file_tugas`, `deadline_tugas`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 2, 2, 'Ut in sunt voluptat', 'Voluptatem similique', '1613704323.pdf', '1982-12-18', '2021-02-18 20:12:03', '2021-02-18 20:12:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_s` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `username`, `password`, `id_s`, `level`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, 'admin', '$2y$10$zIgHDBB52b.CPLUNUjMNY.XQUI8ndAVjtAyJH.8XEODOg95RIEyVS', 6, 4, NULL, NULL, NULL),
(8, 'guru', '$2y$10$MzVxiiFvOuOKlT.qsF/1su7fkp.tneDT2Z4nEx.snJxBnF9CeWQd.', 2, 3, NULL, NULL, NULL),
(9, 'topan', '$2y$10$JTT1fw01QN4lDrsUQ3eSceCeIcEFvUZFnHMTIZ6It3M/G3P7Yk6OC', 2, 3, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cle`
--
ALTER TABLE `cle`
  ADD PRIMARY KEY (`id_kirim_tugas`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`(191));

--
-- Indexes for table `tb_absensi`
--
ALTER TABLE `tb_absensi`
  ADD PRIMARY KEY (`id_absen`);

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tb_cuti`
--
ALTER TABLE `tb_cuti`
  ADD PRIMARY KEY (`id_cuti`);

--
-- Indexes for table `tb_guru`
--
ALTER TABLE `tb_guru`
  ADD PRIMARY KEY (`id_guru`);

--
-- Indexes for table `tb_hari`
--
ALTER TABLE `tb_hari`
  ADD PRIMARY KEY (`id_hari`);

--
-- Indexes for table `tb_izin`
--
ALTER TABLE `tb_izin`
  ADD PRIMARY KEY (`id_izin`);

--
-- Indexes for table `tb_jabatan`
--
ALTER TABLE `tb_jabatan`
  ADD PRIMARY KEY (`id_jabatan`);

--
-- Indexes for table `tb_jadwal_pelajaran`
--
ALTER TABLE `tb_jadwal_pelajaran`
  ADD PRIMARY KEY (`id_jadwal_pelajaran`);

--
-- Indexes for table `tb_jadwal_ujian`
--
ALTER TABLE `tb_jadwal_ujian`
  ADD PRIMARY KEY (`id_jadwal_ujian`);

--
-- Indexes for table `tb_jam_ajar`
--
ALTER TABLE `tb_jam_ajar`
  ADD PRIMARY KEY (`id_jam`);

--
-- Indexes for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `tb_kirim_tugas`
--
ALTER TABLE `tb_kirim_tugas`
  ADD PRIMARY KEY (`id_kirim_tugas`);

--
-- Indexes for table `tb_lapor`
--
ALTER TABLE `tb_lapor`
  ADD PRIMARY KEY (`id_lapor`);

--
-- Indexes for table `tb_materi`
--
ALTER TABLE `tb_materi`
  ADD PRIMARY KEY (`id_materi`);

--
-- Indexes for table `tb_nilai`
--
ALTER TABLE `tb_nilai`
  ADD PRIMARY KEY (`id_nilai`);

--
-- Indexes for table `tb_pegawai`
--
ALTER TABLE `tb_pegawai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_pelajaran`
--
ALTER TABLE `tb_pelajaran`
  ADD PRIMARY KEY (`id_pelajaran`);

--
-- Indexes for table `tb_quis`
--
ALTER TABLE `tb_quis`
  ADD PRIMARY KEY (`id_quis`);

--
-- Indexes for table `tb_semester`
--
ALTER TABLE `tb_semester`
  ADD PRIMARY KEY (`id_semester`);

--
-- Indexes for table `tb_siswa`
--
ALTER TABLE `tb_siswa`
  ADD PRIMARY KEY (`id_siswa`);

--
-- Indexes for table `tb_spp`
--
ALTER TABLE `tb_spp`
  ADD PRIMARY KEY (`id_spp`);

--
-- Indexes for table `tb_tugas`
--
ALTER TABLE `tb_tugas`
  ADD PRIMARY KEY (`id_tugas`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cle`
--
ALTER TABLE `cle`
  MODIFY `id_kirim_tugas` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tb_absensi`
--
ALTER TABLE `tb_absensi`
  MODIFY `id_absen` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `admin_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_cuti`
--
ALTER TABLE `tb_cuti`
  MODIFY `id_cuti` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_guru`
--
ALTER TABLE `tb_guru`
  MODIFY `id_guru` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_hari`
--
ALTER TABLE `tb_hari`
  MODIFY `id_hari` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tb_izin`
--
ALTER TABLE `tb_izin`
  MODIFY `id_izin` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_jabatan`
--
ALTER TABLE `tb_jabatan`
  MODIFY `id_jabatan` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_jadwal_pelajaran`
--
ALTER TABLE `tb_jadwal_pelajaran`
  MODIFY `id_jadwal_pelajaran` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_jadwal_ujian`
--
ALTER TABLE `tb_jadwal_ujian`
  MODIFY `id_jadwal_ujian` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_jam_ajar`
--
ALTER TABLE `tb_jam_ajar`
  MODIFY `id_jam` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  MODIFY `id_kelas` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_kirim_tugas`
--
ALTER TABLE `tb_kirim_tugas`
  MODIFY `id_kirim_tugas` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_lapor`
--
ALTER TABLE `tb_lapor`
  MODIFY `id_lapor` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_materi`
--
ALTER TABLE `tb_materi`
  MODIFY `id_materi` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_nilai`
--
ALTER TABLE `tb_nilai`
  MODIFY `id_nilai` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_pegawai`
--
ALTER TABLE `tb_pegawai`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_pelajaran`
--
ALTER TABLE `tb_pelajaran`
  MODIFY `id_pelajaran` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_quis`
--
ALTER TABLE `tb_quis`
  MODIFY `id_quis` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_semester`
--
ALTER TABLE `tb_semester`
  MODIFY `id_semester` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_siswa`
--
ALTER TABLE `tb_siswa`
  MODIFY `id_siswa` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_spp`
--
ALTER TABLE `tb_spp`
  MODIFY `id_spp` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_tugas`
--
ALTER TABLE `tb_tugas`
  MODIFY `id_tugas` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
