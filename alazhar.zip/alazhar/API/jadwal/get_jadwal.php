<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}
include_once '../class/database.php';

$database = new Database();
$conn = $database->getConnection();
$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,'Page Not Found');
}elseif ( !isset($_POST['kelas']) || !isset($_POST['grup']) || !isset($_POST['hari']) || empty(trim($_POST['kelas'])) || empty(trim($_POST['grup'])) || empty(trim($_POST['hari']))
) {
    $returnData = msg(0,422,'Harap isi field kosong');
}
else{
    $kelas = $_POST['kelas'];
    $grup = $_POST['grup'];
    $hari = $_POST['hari'];

    $query = "SELECT j.*, a.*, k.*, p.*, pg.*, h.*
    FROM tb_jadwal_pelajaran j 
    LEFT JOIN tb_jam_ajar a ON j.id_jam_ajar = a.id_jam
    LEFT JOIN tb_kelas k ON j.id_kelas = k.id_kelas
    LEFT JOIN tb_pelajaran p ON j.id_pelajaran = p.id_pelajaran
    LEFT JOIN tb_pegawai pg ON j.id_pegawai = pg.id
    LEFT JOIN tb_hari h ON j.id_hari = h.id_hari
    WHERE k.nama_kelas = :kls AND k.grup_kelas = :grup AND j.id_hari = :hari
    ORDER BY a.jam_awal ASC
    ";


    $stmt = $conn->prepare($query);
    $stmt->bindParam(":kls",$kelas);
    $stmt->bindParam("grup", $grup);
    $stmt->bindParam(":hari", $hari);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data = array();
        $data["DATA"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $item = array(
                "id" => $row['id_jadwal_pelajaran'],
                "jam_awal" =>$row['jam_awal'],
                "jam_akhir" => $row['jam_akhir'],
                "kelas" => $row['nama_kelas'],
                "grup" => $row['grup_kelas'],
                "matpel" => $row['nama_pelajaran'],
                "hari" => $row['hari'],
                "nama_guru" => $row['nama_peg'],
                "nip" => $row['nip']
            );
            array_push($data["DATA"],$item);
        }
        $returnData = msg(1,200,'Data ada',$data);
    }else{
        $returnData = msg(0,422,'Data tidak ada');
    }
}
echo json_encode($returnData);
?>