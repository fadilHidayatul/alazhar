<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';
include_once '../class/jwthandler.php';

$database = new Database();
$conn = $database->getConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,"Page Not Found");
}elseif(!isset($_POST['username']) || !isset($_POST['password']) || empty(trim($_POST['username'])) || empty(trim($_POST['password']))  ){
    $field = ['Fields' => ['username','password']];
    $returnData = msg(0,422,'Harap isi field yang kosong',$field);
}else {
    $uname = $_POST['username'];
    $pass = $_POST['password'];

    try{
        $query = "SELECT * FROM tb_user WHERE username = :uname AND level=4";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(":uname",$uname);
        $stmt->execute();

        if ($stmt->rowCount()) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $chk_pass = password_verify($pass, $row['password']);
            
           if ($chk_pass) {
                $returnData = [
                    'status' => 200,
                    'message' => 'Success Login',
                    'data' => array(
                        'id_user' => $row['id_user'],
                        'username' =>$row['username'],
                        'id_pegawai' => $row['id_s'],
                        'level' => $row['level']
                    )
                ];
           }else {
               $returnData = msg(0,422,'Password Salah');
           }
        }else {
            $returnData = msg(0,422,'User tidak ada');
        }

    }catch(PDOException $e){
        $returnData = msg(0,500,$e->getMessage());
    }
}
echo json_encode($returnData);
?>