<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}
include_once '../class/database.php';

$database = new Database();
$conn = $database->getConnection();
$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,'Page Not Found');
}elseif( !isset($_POST['id_user']) || empty(trim($_POST['id_user']))
){
    $returnData = msg(0,422, 'Isi Field yang dibutuhkan');
}else {
    $idUser = $_POST['id_user'];

    $query = "SELECT * FROM tb_pegawai WHERE id = :id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":id", $idUser);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data["DATA"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $item = array(
                "nip" => $row['nip'],
                "nama" => $row['nama_peg'],
                "email" => $row['Email'],
                "tlp" => $row['no_tlp'],
                "alamat" => $row['alamat'],
                "masuk" => $row['tgl_masuk'],
                "pendidikan" => $row['pendidikan']
            );
            array_push($data["DATA"],$item);
        }
        $returnData = msg(1,200,'Data ada',$data);
    }else{
        $returnData = msg(0,201,'Data tidak ada');
    }
}

echo json_encode($returnData);
?>