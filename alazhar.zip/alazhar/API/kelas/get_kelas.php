<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: access");
    header("Access-Control-Allow-Methods: GET");
    header("Access-Control-Allow-Credentials: true");
    header('Content-Type: application/json');
    
    function msg($success,$status,$message,$extra = []){
        return array_merge([
            'success' => $success,
            'status' => $status,
            'message' => $message
        ],$extra);
    }
    include_once '../class/database.php';
    
    $database = new Database();
    $conn = $database->getConnection();
    $returnData = [];

    if ($_SERVER["REQUEST_METHOD"]!="GET") {
        $returnData = msg(0,404,'Page Not Found');
    }else {
        //ambil kelas dan grup
        $query1 = "SELECT * FROM tb_kelas";
        $klsgrp = $conn->prepare($query1);
        $klsgrp->execute();
        
        if ($klsgrp->rowCount() > 0) {
            $data = array();
            $data["DATA"] = array();

            while ($row = $klsgrp->fetch(PDO::FETCH_ASSOC)) {
                extract($row);

                //ambil banyak kelas
                $idkelas = $row['id_kelas'];
                $query = "SELECT * FROM tb_siswa WHERE id_kelas = :kelas";
                $stmt = $conn->prepare($query);
                $stmt->bindParam(":kelas",$idkelas);
                $stmt->execute();

                $item = array(
                    "id_kelas" => $row['id_kelas'],
                    "kelas" => $row['nama_kelas'],
                    "grup" => $row['grup_kelas'],
                    "jumlah_murid" => $stmt->rowCount()
                );
                array_push($data["DATA"],$item);
            }
            $returnData = msg(1,200,'Data ada',$data);
            
        }else{
            $returnData = msg(0,422,'Data tidak ada');
        }

    
    }
    echo json_encode($returnData);
?>