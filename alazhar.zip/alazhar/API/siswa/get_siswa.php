<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}
include_once '../class/database.php';

$database = new Database();
$conn = $database->getConnection();
$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "GET") {
    $returnData = msg(0,404, 'Page not found!');
} else {
    $query = "SELECT s.id_siswa, s.nama_siswa, k.nama_kelas AS kelas, k.grup_kelas AS grup, 
    s.gender_siswa, s.tempat_lahir_siswa, s.tanggal_lahir_siswa
    FROM tb_siswa s LEFT JOIN tb_kelas k ON s.id_kelas = k.id_kelas";

    $statement = $conn->prepare($query);
    $statement->execute();

    if ($statement->rowCount() > 0) {
        $data = array();
        $data["DATA"] = array();

        while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $item = array(
                "id_siswa" => $row['id_siswa'],
                "nama_siswa" => $row['nama_siswa'],
                "kelas" => $row['kelas'],
                "grup" => $row['grup'],
                "gender" => $row['gender_siswa'],
                "tempat_lahir" => $row['tempat_lahir_siswa'],
                "tgl_lahir" => $row['tanggal_lahir_siswa']

            );
            array_push($data["DATA"],$item);
        }
        $returnData = msg(1,200,'Data ada',$data);

    }else {
        $returnData = msg(0,422,'Data tidak ada');
    }
}
echo json_encode($returnData);

?>