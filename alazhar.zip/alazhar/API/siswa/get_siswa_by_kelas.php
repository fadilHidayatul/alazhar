<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}
include_once '../class/database.php';

$database = new Database();
$conn = $database->getConnection();
$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,'Page Not Found');
}elseif ( !isset($_POST['kelas']) || !isset($_POST['grup']) ||
          empty(trim($_POST['kelas'])) || empty(trim($_POST['grup']))
) {
    $returnData = msg(0,422,'Harap isi field yang kosong');
}else {
    $kelas = $_POST['kelas'];
    $grup = $_POST['grup'];

    $query = " SELECT s.*, k.nama_kelas AS kelas, k.grup_kelas AS grup , k.id_kelas AS idkls
    FROM tb_siswa s
    LEFT JOIN tb_kelas k ON s.id_kelas = k.id_kelas
    WHERE k.nama_kelas = :kelas AND k.grup_kelas = :grup
    ORDER BY s.id_siswa DESC
    ";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":kelas", $kelas);
    $stmt->bindParam(":grup", $grup);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data["DATA"] = array();
        $no = 1;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $item = array(
                "no" => $no++,
                "id_siswa" => $row['id_siswa'],
                "siswa" => $row['nama_siswa']
            );
            array_push($data["DATA"], $item);
        }
        $returnData = msg(1,200,'Data ada',$data);
    }else{
        $returnData = msg(1,200,'Data tidak ada');
    }

}
echo json_encode($returnData);
?>