<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}
include_once '../class/database.php';

$database = new Database();
$conn = $database->getConnection();
$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,'Page Not Found');
}elseif ( !isset($_POST['id_siswa']) || !isset($_POST['kelas']) || !isset($_POST['grup']) ||
          empty(trim($_POST['id_siswa'])) || empty(trim($_POST['kelas'])) || empty(trim($_POST['grup']))
) {
    $returnData = msg(0,422,'Harap isi field yang kosong');
}else {
    $idSiswa = $_POST['id_siswa'];
    $kelas = $_POST['kelas'];
    $grup = $_POST['grup'];
    $semester = $_POST['semester'];

    $query = " SELECT l.* , k.nama_kelas AS kelas , k.grup_kelas AS grup , s.nama_siswa AS siswa
    FROM tb_lapor l
    LEFT JOIN tb_kelas k ON l.id_kelas = k.id_kelas
    LEFT JOIN tb_siswa s ON l.id_siswa = s.id_siswa
    LEFT JOIN tb_semester sm ON k.id_semester = sm.id_semester
    WHERE l.id_siswa = :idSiswa AND k.nama_kelas = :kelas AND k.grup_kelas = :grup 
    AND k.id_semester = :smt
    ";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":idSiswa", $idSiswa);
    $stmt->bindParam(":kelas", $kelas);
    $stmt->bindParam(":grup", $grup);
    $stmt->bindParam(":smt", $semester);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data = array();
        $data["DATA"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $item = array(
                "siswa" => $row['siswa'],
                "file" => $row['file']
            );
            array_push($data["DATA"], $item);
        }
        $returnData = msg(1,200,'Data ada',$data);
    }else{
        $returnData = msg(1,201,'Data tidak ada');
    }


}

echo json_encode($returnData);
?>