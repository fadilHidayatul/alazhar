<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}
include_once '../class/database.php';
include_once '../tanggalindo.php';

$database = new Database();
$conn = $database->getConnection();
$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,400,'Page Not Found');
}
elseif ( !isset($_POST['id']) || empty(trim($_POST['id'])) 
) {
    $returnData = msg(0,422,'Harap isi field penting');
}
else{
    $id = $_POST['id'];
    $stts = $_POST['stat'];
    $bln = $_POST['bulan'];
    $thn = $_POST['tahun'];

    $query = "SELECT * FROM tb_spp
    WHERE id_siswa = :id AND status = :status AND bulan_spp = :bln AND tahun_spp = :thn
    ";

    $stmt = $conn->prepare($query);
    $stmt->bindParam(":id",$id);
    $stmt->bindParam(":status",$stts);
    $stmt->bindParam(":bln", $bln);
    $stmt->bindParam(":thn", $thn);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data = array();
        $data["DATA"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $item = array(
                "id_spp" => $row['id_spp'],
                "id_siswa" => $row['id_siswa'],
                "tgl_bayar" => $row['tgl_bayar'],
                "bukti" => $row['upload_bukti'],
                "status" => $row['status']
            );
            array_push($data["DATA"], $item);
        }

        $returnData = msg(1,200,'Data ada',$data);
    }else {
        $returnData = msg(0,201,'Data tidak ada');
    }
}

echo json_encode($returnData);
?>