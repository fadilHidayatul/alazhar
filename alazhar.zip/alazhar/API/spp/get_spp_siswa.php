<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}
include_once '../class/database.php';
include_once '../tanggalindo.php';

$database = new Database();
$conn = $database->getConnection();
$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "GET") {
    $returnData = msg(0,400,'Page Not Found');
}else {
    $bln = $_GET['bulan'];
    $thn = $_GET['tahun'];

    $query = "SELECT sp.id_siswa, sw.nama_siswa FROM tb_spp sp
    LEFT JOIN tb_siswa sw ON sp.id_siswa = sw.id_siswa
    WHERE sp.bulan_spp = :bln AND sp.tahun_spp = :thn
    ORDER BY tgl_bayar ASC
    ";

    $stmt = $conn->prepare($query);
    $stmt->bindParam(":bln", $bln);
    $stmt->bindParam(":thn", $thn);
    $stmt->execute();

    if($stmt->rowCount() > 0){
        $data = array();
        $data["DATA"] = array();
        $no = 1;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $item = array(
                "id_siswa" => $row['id_siswa'],
                "no" => $no++,
                "nama_siswa" => $row['nama_siswa']
            );
            array_push($data["DATA"], $item);
        }
        $returnData = msg(1,200,'data ada',$data);
    }else {
        $returnData = msg(0,422,'data tidak ada');
    }
}
echo json_encode($returnData);
?>