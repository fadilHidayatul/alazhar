<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}
include_once '../class/database.php';
include_once '../tanggalindo.php';

$database = new Database();
$conn = $database->getConnection();
$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,'Not Found');
}else if(!isset($_POST['id']) || empty(trim($_POST['id']))
) {
    $returnData = msg(0,422,'Harap isi field id siswa');
}else{
    $id = $_POST['id'];
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];

    $query = "UPDATE tb_spp SET status = '1' WHERE id_siswa = :id AND bulan_spp = :bln AND tahun_spp = :thn";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":id", $id);
    $stmt->bindParam(":bln", $bulan);
    $stmt->bindParam(":thn", $tahun);
    $stmt->execute();

    if($stmt->rowCount() > 0 ){
       $returnData = msg(1,200,'Berhasil update SPP');
    }else{
        $returnData = msg(0,201,'Data sudah di update');
    }
}

echo json_encode($returnData);
?>